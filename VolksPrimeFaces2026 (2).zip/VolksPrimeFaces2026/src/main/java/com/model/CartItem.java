package com.model;
import java.io.Serializable;

public class CartItem implements Serializable {

    private String name;
    private Double price;
    private Integer quantity;
    public CartItem() {}
    public CartItem(String name, Double price, Integer quantity) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }

    public void setPrice(Double price) {
		this.price = price;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Double getPrice() {
		return price;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setName(String name) {
		this.name = name;
	}

	

	public double getTotal() {
		
		    return price * quantity;
		    }

    // Getters
    public String getName() { return name; }
    }