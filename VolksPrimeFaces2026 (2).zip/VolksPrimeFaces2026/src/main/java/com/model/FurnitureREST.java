package com.model;

public class FurnitureREST {
	 private int id;
	    private String productName;
	    private int quantity;
	    private double price;

	    private double total;
	    private double discount;
	    private double finalAmount;
		public FurnitureREST()
		{
			
		}
	    public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getProductName() {
			return productName;
		}
		public void setProductName(String productName) {
			this.productName = productName;
		}
		public int getQuantity() {
			return quantity;
		}
		public void setQuantity(int quantity) {
			this.quantity = quantity;
		}
		public double getPrice() {
			return price;
		}
		public void setPrice(double price) {
			this.price = price;
		}
		public double getTotal() {
			return total;
		}
		public void setTotal(double total) {
			this.total = total;
		}
		public double getDiscount() {
			return discount;
		}
		public void setDiscount(double discount) {
			this.discount = discount;
		}
		public double getFinalAmount() {
			return finalAmount;
		}
		public void setFinalAmount(double finalAmount) {
			this.finalAmount = finalAmount;
		}
}
