package com.model;
public class Item {
    private String product;
    private int qty;
    public Item() {}
    public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	private double total;

    public Item(String product, int qty, double total) {
        this.product = product;
        this.qty = qty;
        this.total = total;
    }

    
}