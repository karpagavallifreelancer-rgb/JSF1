package com.model;
public class Player {

    private String name;
    private int matches;
    private int runs;
    private int balls;
    private int outs;

    public double getStrikeRate() {
        return balls == 0 ? 0 : (runs * 100.0) / balls;
    }

    public double getAverage() {
        return outs == 0 ? runs : (runs * 1.0) / outs;
    }

    // Getters & Setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public int getMatches() { return matches; }
    public void setMatches(int matches) { this.matches = matches; }

    public int getRuns() { return runs; }
    public void setRuns(int runs) { this.runs = runs; }

    public int getBalls() { return balls; }
    public void setBalls(int balls) { this.balls = balls; }

    public int getOuts() { return outs; }
    public void setOuts(int outs) { this.outs = outs; }
}