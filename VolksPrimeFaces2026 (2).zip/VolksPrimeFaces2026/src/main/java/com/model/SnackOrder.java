package com.model;

import jakarta.validation.constraints.*;

public class SnackOrder {

    @NotBlank(message = "Customer name required")
    private String customerName;

    @NotNull(message = "Select snack")
    private String snack;

    @Min(value = 1, message = "Minimum quantity is 1")
    @Max(value = 50, message = "Max 50 allowed")
    private int quantity;

    @Min(value = 10, message = "Price must be >= 10")
    private double price;

    private double total;

    private boolean bulkOrder;

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getSnack() {
		return snack;
	}

	public void setSnack(String snack) {
		this.snack = snack;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public boolean isBulkOrder() {
		return bulkOrder;
	}

	public void setBulkOrder(boolean bulkOrder) {
		this.bulkOrder = bulkOrder;
	}

    // getters & setters
    
}