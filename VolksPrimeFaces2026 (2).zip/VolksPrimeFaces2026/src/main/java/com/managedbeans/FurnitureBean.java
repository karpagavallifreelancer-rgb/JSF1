package com.managedbeans;

import java.io.Serializable;

import com.model.Furniture;


import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;
/*
 * 🔗 1. JSON Binding

Meaning: Conversion between JSON ⇄ Java objects

🔄 Types
1. Serialization (Java → JSON)
mapper.writeValueAsString(obj);

2. Deserialization (JSON → Java)
mapper.readValue(json, ClassName.class);

📏 Rules
✔ Must have default constructor
✔ Must have getters/setters
✔ Field names should match JSON keys
✔ Use annotations if needed:
@JsonProperty("cust_name")
✔ Ignore extra fields:
@JsonIgnoreProperties(ignoreUnknown = true)
✔ Use correct data types (int, double, List, etc.)

*******JSF uses Java fields
*********JSON annotations are only for API communication

When @JsonProperty is actually used?

Only when you do JSON conversion, like:

1. REST API input/output (Spring Boot / JAX-RS)

🧩 Binding Categories
1. Simple
{ "name": "John", "age": 25 }
2. Nested
{ "customer": { "name": "John" } }
3. Collection
{ "items": [ { "name": "Pen" }, { "name": "Book" } ] }

⚠️ 2. Error Handling

Meaning: Handling issues during JSON processing or validation

❌ Types
1. Parsing Error
Invalid JSON format

2. Mapping Error
Type mismatch (string → int, etc.)

3. Validation Error
Violates rules:
@NotNull
@Min(1)

4. Missing Fields
Required data not provided

5. Unknown Fields
Extra unexpected JSON fields

🛠 Handling Methods
✔ Try-Catch
try {
   mapper.readValue(json, Obj.class);
} catch (Exception e) {}

✔ Specific Exceptions
JsonParseException
JsonMappingException

✔ Validation Check
if(qty <= 0) throw new IllegalArgumentException();

✔ API Error Response
{ "status":"error", "message":"Invalid input" }

📊 Summary
JSON Binding
Serialization
Deserialization
Simple / Nested / Collection
Rules (POJO + annotations)

Error Handling
Parsing errors
Mapping errors
Validation errors
Missing/unknown fields
Exception handling + API response
 */
//JSON Binding + Error Handling

@Named
@ViewScoped
//Furniture.java->FurnitureBean.java->jsonbinding.xhtml
public class FurnitureBean implements Serializable {

    private String productName;
    private Integer quantity = 0;
    private Double price = 0.0;
    private Double discount = 0.0;
    private Double total = 0.0;

    // 🔢 Calculation
    public void calculate() {
        try {
            double subtotal = quantity * price;
            double discountAmount = subtotal * (discount / 100);//10% of 200 = 20
            total = subtotal - discountAmount;
        } catch (Exception e) {
            addError("Calculation error");
        }
    }

    // 📦 Submit + JSON Binding
    public void submit() {
        try {
            // Create object
            Furniture furniture = new Furniture();//Create POJO object
            furniture.setProductName(productName);//Copy data from bean → POJO
            furniture.setQuantity(quantity);
            furniture.setPrice(price);
            furniture.setDiscount(discount);
            furniture.setTotal(total);

            // Convert to JSON
            ObjectMapper mapper = new ObjectMapper();//Used for JSON conversion
            String json = mapper.writeValueAsString(furniture);//Converts Java object → JSON string(Serialization)

            System.out.println("JSON OUTPUT: " + json);

            addInfo("Order saved successfully");

        } catch (Exception e) {
            addError("Error converting to JSON");
        }
    }

    // ✅ Feedback Methods
    private void addInfo(String msg) {
        FacesContext.getCurrentInstance().addMessage(null,
            new FacesMessage(FacesMessage.SEVERITY_INFO, "Success", msg));
    }

    private void addError(String msg) {
        FacesContext.getCurrentInstance().addMessage(null,
            new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", msg));
    }

    // Getters & Setters
    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }

    public Integer getQuantity() { return quantity; }
    public void setQuantity(Integer quantity) { this.quantity = quantity; }

    public Double getPrice() { return price; }
    public void setPrice(Double price) { this.price = price; }

    public Double getDiscount() { return discount; }
    public void setDiscount(Double discount) { this.discount = discount; }

    public Double getTotal() { return total; }
    public void setTotal(Double total) { this.total = total; }
}