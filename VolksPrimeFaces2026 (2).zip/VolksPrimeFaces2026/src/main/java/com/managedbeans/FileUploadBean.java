package com.managedbeans;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.Serializable;

import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.file.UploadedFile;

import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;
@Named
@ViewScoped
//FileUploadBean.java->fileuploaddemo.xhtml

//CHECK WEB.XML
public class FileUploadBean implements Serializable {

    private String fileContent;//Stores the text content of uploaded file

    public void setFileContent(String fileContent) {
		this.fileContent = fileContent;
	}
    //This method is triggered when file is uploaded
    public void handleFileUpload(FileUploadEvent event) {
        System.out.println("🔥 METHOD CALLED");
        FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage("Upload triggered"));

        UploadedFile file = event.getFile();//Get Uploaded File

        System.out.println("File: " + file.getFileName());

        try {
            String fileName = file.getFileName();

            if (!fileName.endsWith(".txt")) {//Validate File Type
                fileContent = "❌ Only .txt files can be displayed!";
                return;
            }

            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(file.getInputStream()));//Read File

            StringBuilder sb = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }

            fileContent = sb.toString();//Final file content stored

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public String getFileContent() {
        return fileContent;
    }
}