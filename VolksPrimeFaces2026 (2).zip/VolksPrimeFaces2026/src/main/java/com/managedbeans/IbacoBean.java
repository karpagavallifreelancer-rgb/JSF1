package com.managedbeans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.primefaces.event.FlowEvent;
import org.primefaces.model.charts.ChartData;
import org.primefaces.model.charts.bar.BarChartDataSet;
import org.primefaces.model.charts.bar.BarChartModel;
import org.primefaces.model.charts.bar.BarChartOptions;
import org.primefaces.model.charts.optionconfig.title.Title;

import jakarta.annotation.PostConstruct;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;

/*
 * 🎯 1. Charts
Category: Data Visualization Components

Types:
Bar Chart
Line Chart
Pie Chart
Doughnut Chart
Radar Chart

Rules:
Requires a Model class (ChartModel, BarChartModel)
Data must be set from Managed Bean
Works with AJAX updates
Needs proper JSON-like structure internally

👉 Use when:
Showing reports, analytics, trends

🎯 2. Dashboards
Category: Layout + Widget Management

Types:
Static dashboard
Dynamic dashboard (drag & drop widgets)

Rules:
Uses <p:dashboard> and <p:panel>
Widgets must have unique IDs
Supports reordering via drag-drop
Backend must handle layout changes (optional)

👉 Use when:
Admin panels
Monitoring systems

🎯 3. File Upload
Category: Input / I-O Components

Types:
Simple upload (mode="simple")
Advanced upload (mode="advanced")
Auto upload
Drag & drop

Rules:
Requires:
enctype="multipart/form-data"
Needs fileUploadListener method
File size/type validation required
Server config must allow upload size

👉 Use when:
Uploading documents, images, reports

🎯 4. Wizards
Category: Navigation / Workflow Components
Types:
Linear wizard (step-by-step)
Conditional wizard (dynamic flow)

Rules:
Uses <p:wizard>
Each step = <p:tab>
Controlled by flowListener method
Maintains state in ViewScoped bean

👉 Use when:
Multi-step forms (registration, checkout)

| Component   | Category            | Purpose              |
| ----------- | ------------------- | -------------------- |
| Charts      | Data Visualization  | Show analytics       |
| Dashboards  | Layout / Containers | Organize widgets     |
| File Upload | Input / I-O         | Accept files         |
| Wizards     | Navigation / Flow   | Step-by-step process |


Charts → Need model + data binding
Dashboard → Drag-drop layout control
File Upload → Multipart + listener required
Wizard → Flow control + ViewScoped
 */
@Named
@ViewScoped

/*
 * Component Mapping::How UI talks to Java and comes back with updated data
 * 
 * UI Component ⇄ Managed Bean ⇄ Business Logic ⇄ UI Update
 * 
 * 	📂 Categories

Data Mapping → value="#{bean.field}"
Action Mapping → action="#{bean.method}"
Event Mapping → <p:ajax listener="#{bean.method}" />

🔹 Types

Property → bind field (inputText → name)
Computed → derived value (getTotal())
Collection → list/table (dataTable)
Selection → dropdown (selectOneMenu)
Event/Row → edit, click, AJAX
Conversion → UI type ↔ Java type

📏 Rules

✔ Getter/Setter required
✔ Correct scope (@ViewScoped for PrimeFaces)
✔ Matching data types
✔ Correct component IDs (update="form:id")
✔ Use process & update properly
✔ Proper bean name (@Named)
 */
//IbacoBean.java->ibaco_chartdashboardfileuploadwizard.xhtml
public class IbacoBean implements Serializable {
/*
 * ✅ Form handling
✅ Business logic (billing)
✅ Dashboard metrics
✅ Chart visualization
✅ Wizard navigation
✅ JSF lifecycle integration
 */
    private String customerName;
    private String mobile;
    private String address;
    private String flavor;
    private String productType;
    private Integer quantity;
    private Double unitPrice;
    private Double discount;
    private Double gst;

    private Double subtotal;
    private Double discountAmount;
    private Double gstAmount;
    private Double finalAmount;

    //Dashboard Fields->display summary cards in UI
    private Integer totalOrders;
    private Double totalRevenue;
    private String bestFlavor;
    private Integer pendingDeliveries;
    private Integer totalCustomers;

    private BarChartModel barModel;

    //Page Load Setup
    @PostConstruct
    public void init() {
        totalOrders = 120;
        totalRevenue = 85000.0;
        bestFlavor = "Chocolate";
        pendingDeliveries = 8;
        totalCustomers = 95;

        createBarModel();
    }

    public void calculateBill() {
        subtotal = quantity * unitPrice;
        discountAmount = subtotal * (discount / 100);
        double afterDiscount = subtotal - discountAmount;
        gstAmount = afterDiscount * (gst / 100);
        finalAmount = afterDiscount + gstAmount;

        //Shows Growl / Messages in UI
        FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO,
                        "Success",
                        "Bill Calculated Successfully"));
    }

    public void createBarModel() {

        barModel = new BarChartModel();//Create Model
        ChartData data = new ChartData();

        BarChartDataSet dataSet = new BarChartDataSet();//Dataset
        dataSet.setLabel("Flavor Sales");

        List<Number> values = new ArrayList<>();//Values
        values.add(120);//Y-AXIS
        values.add(95);
        values.add(75);
        values.add(60);

        dataSet.setData(values);

        data.addChartDataSet(dataSet);
        //Labels
        data.setLabels(Arrays.asList(
                "Chocolate",//X-AXIS 
                "Vanilla",
                "Strawberry",
                "Butterscotch"
        ));

        barModel.setData(data);

        BarChartOptions options = new BarChartOptions();

        Title title = new Title();
        title.setDisplay(true);
        title.setText("Ibaco Flavor Sales Report");

        options.setTitle(title);

        barModel.setOptions(options);//A bar chart showing sales per flavor
    }
    //Wizard Navigation->Controls step-by-step navigation
    public String onFlowProcess(FlowEvent event) {
        return event.getNewStep();
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getFlavor() {
        return flavor;
    }

    public void setFlavor(String flavor) {
        this.flavor = flavor;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(Double unitPrice) {
        this.unitPrice = unitPrice;
    }

    public Double getDiscount() {
        return discount;
    }

    public void setDiscount(Double discount) {
        this.discount = discount;
    }

    public Double getGst() {
        return gst;
    }

    public void setGst(Double gst) {
        this.gst = gst;
    }

    public Double getSubtotal() {
        return subtotal;
    }

    public Double getDiscountAmount() {
        return discountAmount;
    }

    public Double getGstAmount() {
        return gstAmount;
    }

    public Double getFinalAmount() {
        return finalAmount;
    }

    public Integer getTotalOrders() {
        return totalOrders;
    }

    public Double getTotalRevenue() {
        return totalRevenue;
    }

    public String getBestFlavor() {
        return bestFlavor;
    }

    public Integer getPendingDeliveries() {
        return pendingDeliveries;
    }

    public Integer getTotalCustomers() {
        return totalCustomers;
    }

    public BarChartModel getBarModel() {
        return barModel;
    }
}
