package com.managedbeans;

import java.io.Serializable;

import com.model.SnackOrder;

import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;

@Named
@ViewScoped
//SnackOrder.java->SnackBean.java->snacksbeanvalidation.xhtml

public class SnackBean implements Serializable {

    private SnackOrder order = new SnackOrder();

    private boolean formValid = false;

    // 🔹 Price Calculation based on snack
    public void calculatePrice() {
        if (order.getSnack() == null) return;

        switch (order.getSnack()) {
            case "Chips": order.setPrice(20); break;
            case "Cookies": order.setPrice(50); break;
            case "Samosa": order.setPrice(15); break;
        }

        calculateTotal();
    }
    private double discount;
    // 🔹 Total Calculation
    public void calculateTotal() {
        double total = order.getPrice() * order.getQuantity();

        // Bulk discount (Cross-field logic)
        if (order.getQuantity() > 10) {
        	discount = total * 10 / 100;
        	total = total - discount;
            order.setBulkOrder(true);
        } else {
            order.setBulkOrder(false);
            discount = 0;//Reset discount when no bulk:
        }

        order.setTotal(total);

        validateForm();
    }
    public double getDiscount() {
        return discount;
    }
    // 🔹 Cross-field validation
    public void validateForm() {
        formValid = true;

        if (order.getSnack() == null || order.getQuantity() <= 0) {
            formValid = false;
        }

        // Custom rule
        if ("Samosa".equals(order.getSnack()) && order.getQuantity() > 20) {
            formValid = false;
        }
    }

    // 🔹 Submit
    public void submit() {
        FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO,
                        "Success",
                        "Order Placed! Total: ₹" + order.getTotal()));
    }

    // getters & setters
    public SnackOrder getOrder() { return order; }
    public boolean isFormValid() { return formValid; }
}