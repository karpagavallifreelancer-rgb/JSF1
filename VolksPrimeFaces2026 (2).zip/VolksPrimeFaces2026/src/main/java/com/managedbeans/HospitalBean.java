package com.managedbeans;

import java.io.Serializable;

import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
/*
 * )

🔄 Loading Indicators

Show that a process is in progress.

Types:

Spinner → short tasks
Progress bar → Used for long tasks (file upload, reports),Shows percentage completion
Skeleton → content loading
Overlay Loader (Blocking UI) → prevent interaction

🎯 Display Components in PrimeFaces
1.Growl (Auto popup) <p:growl life="3000" />
Non-blocking
Disappears automatically

2.🔹 Messages (Inline)
Shown inside form <p:messages />

3.🔹 Dialog (Popup) <p:dialog/>
Important messages

 */
//HospitalBean.java->loadingindicatordemo.xhtml
@Named
@ViewScoped
public class HospitalBean implements Serializable {

    private String name;
    private Integer age;
    private Double consultationFee = 0.0;
    private Double labCharges = 0.0;
    private Double discount = 0.0;
    private Double total = 0.0;

    // 🔢 Calculation
    public void calculate() {
        double subtotal = consultationFee + labCharges;
        double discountAmount = subtotal * (discount / 100);
        total = subtotal - discountAmount;
    }

    // ✅ Form validation logic
    public boolean isFormValid() {
        return name != null && !name.isEmpty()
                && age != null && age > 0
                && total != null && total > 0;
    }

    // 🎯 Submit
    public void submit() {
        FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO,
                        "Success",
                        "Bill Generated: ₹ " + total));
    }

    // Getters & Setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public Integer getAge() { return age; }
    public void setAge(Integer age) { this.age = age; }

    public Double getConsultationFee() { return consultationFee; }
    public void setConsultationFee(Double consultationFee) { this.consultationFee = consultationFee; }

    public Double getLabCharges() { return labCharges; }
    public void setLabCharges(Double labCharges) { this.labCharges = labCharges; }

    public Double getDiscount() { return discount; }
    public void setDiscount(Double discount) { this.discount = discount; }

    public Double getTotal() { return total; }
    public void setTotal(Double total) { this.total = total; }
}