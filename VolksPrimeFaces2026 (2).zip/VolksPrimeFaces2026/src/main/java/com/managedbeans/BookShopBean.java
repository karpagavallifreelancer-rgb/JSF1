package com.managedbeans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.primefaces.event.RowEditEvent;

import com.model.Book;

import jakarta.annotation.PostConstruct;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;

@Named
@ViewScoped
/*
 * ○ Inline editing  
○ Notifications 
 */
//Book.java->BookShopBean.java->inlineeditingnotificationdemo.xhtml
public class BookShopBean implements Serializable {

    private List<Book> books;

    @PostConstruct
    //Data Initialization
    public void init() {
        books = new ArrayList<>();

        books.add(new Book(1, "Java Basics", 450.0));
        books.add(new Book(2, "Spring Boot", 650.0));
        books.add(new Book(3, "Hibernate Guide", 550.0));
    }

    // Row Edit Event
    public void onRowEdit(RowEditEvent<Book> event) {
        Book book = event.getObject();//Gets edited row

        FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage("Updated",
                        book.getTitle() + " updated successfully"));//Triggered when user clicks ✔ (save)
    }
//Row Cancel Event
    public void onRowCancel(RowEditEvent<Book> event) {
        FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage("Cancelled", "Edit cancelled"));//Triggered when user clicks ❌
    }

    public List<Book> getBooks() {
        return books;
    }
}