package com.managedbeans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.primefaces.model.FilterMeta;
import org.primefaces.model.LazyDataModel;

import com.model.Player;

import jakarta.annotation.PostConstruct;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;

//Player.java->CricketBeanLazyDemo.java->cricketlazydemo.xhtml
@Named("cricketBean")
@ViewScoped
public class CricketBeanLazyDemo implements Serializable {
/*
 * ✔ PrimeFaces lazy table model
👉 Used for pagination + filtering without loading full DB each time
 */
    private LazyDataModel<Player> lazyModel;
    public List<Player> getDatasource() {
		return datasource;
	}

	public void setDatasource(List<Player> datasource) {
		this.datasource = datasource;
	}

	public void setLazyModel(LazyDataModel<Player> lazyModel) {
		this.lazyModel = lazyModel;
	}

	private List<Player> datasource;//In-memory database (100 players stored here)

    @PostConstruct
    public void init() {

        datasource = new ArrayList<>();

        for (int i = 1; i <= 100; i++) {
            Player p = new Player();
            p.setName("Player " + i);
            p.setMatches(50 + i);
            p.setRuns(1000 + i * 10);
            p.setBalls(800 + i * 5);
            p.setOuts(40 + i);
            datasource.add(p);
        }

        lazyModel = new LazyDataModel<Player>() {

            @Override
            public List<Player> load(int first, int pageSize,
                                    Map<String, org.primefaces.model.SortMeta> sortBy,
                                    Map<String, FilterMeta> filterBy) {

                List<Player> filtered = new ArrayList<>();

                String nameFilter = null;
                String matchesFilter = null;
                String runsFilter = null;

                if (filterBy != null) {
                    if (filterBy.get("name") != null && filterBy.get("name").getFilterValue() != null) {
                        nameFilter = filterBy.get("name").getFilterValue().toString().toLowerCase();
                    }
                    if (filterBy.get("matches") != null && filterBy.get("matches").getFilterValue() != null) {
                        matchesFilter = filterBy.get("matches").getFilterValue().toString();
                    }
                    if (filterBy.get("runs") != null && filterBy.get("runs").getFilterValue() != null) {
                        runsFilter = filterBy.get("runs").getFilterValue().toString();
                    }
                }

                for (Player p : datasource) {

                    boolean match = true;

                    // Name filter
                    if (nameFilter != null && !nameFilter.isEmpty()) {
                        match &= p.getName().toLowerCase().contains(nameFilter);
                    }

                    // Matches filter
                    if (matchesFilter != null && !matchesFilter.isEmpty()) {
                        match &= p.getMatches() == Integer.parseInt(matchesFilter);
                    }

                    // Runs filter
                    if (runsFilter != null && !runsFilter.isEmpty()) {
                        match &= p.getRuns() == Integer.parseInt(runsFilter);
                    }

                    if (match) {
                        filtered.add(p);
                    }
                }

                setRowCount(filtered.size());

                int end = Math.min(first + pageSize, filtered.size());
                return filtered.subList(first, end);
            }

            @Override
            public int count(Map<String, FilterMeta> filterBy) {
                return datasource.size();
            }
        };
    }

    public LazyDataModel<Player> getLazyModel() {
        return lazyModel;
    }
}