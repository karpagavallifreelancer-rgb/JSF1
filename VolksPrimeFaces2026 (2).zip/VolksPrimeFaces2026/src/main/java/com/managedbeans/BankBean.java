package com.managedbeans;

import java.io.Serializable;

import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;
/*
 * Eclipse uses an embedded browser engine (often old Chromium / WebKit / IE-based depending on setup), 
 * which has:

Poor JavaScript support
Broken AJAX handling
Issues with JSF jsf.js and PrimeFaces scripts
Problems with partial page updates (update, process)

👉 PrimeFaces heavily depends on modern JS + AJAX, so it breaks there.

✅ What you should do (Best Practice)

👉 Always test JSF / PrimeFaces apps in real browsers:

Google Chrome ✅ (best)
Microsoft Edge ✅
Firefox ✅

❌ Avoid:

Eclipse internal browser
Old embedded browsers
 */
@Named
@ViewScoped
//BankBean.java=>banking.xhtml

public class BankBean implements Serializable {

    private String page = "dashboard";

    // Dashboard
    private double balance = 125000;
    private double lastTransaction = 5000;

    // Transfer
    private double amount;
    private String type;
    public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public double getLastTransaction() {
		return lastTransaction;
	}

	public void setLastTransaction(double lastTransaction) {
		this.lastTransaction = lastTransaction;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getCharges() {
		return charges;
	}

	public void setCharges(double charges) {
		this.charges = charges;
	}

	public double getGst() {
		return gst;
	}

	public void setGst(double gst) {
		this.gst = gst;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public double getLoan() {
		return loan;
	}

	public void setLoan(double loan) {
		this.loan = loan;
	}

	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	public int getMonths() {
		return months;
	}

	public void setMonths(int months) {
		this.months = months;
	}

	public double getEmi() {
		return emi;
	}

	public void setEmi(double emi) {
		this.emi = emi;
	}

	public double getTotalInterest() {
		return totalInterest;
	}

	public void setTotalInterest(double totalInterest) {
		this.totalInterest = totalInterest;
	}

	public double getTotalPayment() {
		return totalPayment;
	}

	public void setTotalPayment(double totalPayment) {
		this.totalPayment = totalPayment;
	}

	private double charges;
    private double gst;
    private double total;

    // EMI
    private double loan;
    private double rate;
    private int months;
    private double emi;
    private double totalInterest;
    private double totalPayment;

    // 🔹 Navigation
    public void setPage(String page) {
        this.page = page;
    }

    public String getPage() {
        return page;
    }

    // 🔹 Transfer Calculation
    public void calculateTransfer() {
        if ("IMPS".equals(type)) {
            charges = amount * 0.02;
        } else {
            charges = amount * 0.01;
        }

        gst = charges * 0.18;
        total = amount + charges + gst;
    }

    // 🔹 EMI Calculation
    public void calculateEMI() {
        double r = rate / (12 * 100);

        emi = (loan * r * Math.pow(1 + r, months)) /
              (Math.pow(1 + r, months) - 1);

        totalPayment = emi * months;
        totalInterest = totalPayment - loan;
    }
}