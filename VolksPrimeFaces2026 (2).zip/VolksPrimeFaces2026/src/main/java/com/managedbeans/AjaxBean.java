package com.managedbeans;

import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;

@Named
@RequestScoped
/*
 * PrimeFaces AJAX Lifecycle (Simple Flow)

When you click a PrimeFaces button with ajax="true":

Restore View
Apply Request Values
Process Validations
Update Model Values
Invoke Application (Action Method)
Render Response (Partial Update)
 */

/*
 * 🔍 Attribute Behavior Explained
1.process

👉 Controls what goes through lifecycle

@this	Only button
Value	Meaning
name	Only that field
@form	Full form

2.update
👉 update = which components are re-rendered after AJAX request

Runs in Render Response phase
Only specified UI parts refresh (not whole page)

🎯 Common Values
update="compId" → specific component
update="a b c" → multiple
update="@this" → current component
update="@form" → full form
update="@all" → whole page
update="@none" → no UI update

⚡ Best Practice

✔ Update only needed components
❌ Avoid @all (slow)

👉 update decides what part of UI refreshes after AJAX response

3.immediate="true"

👉 Skips:

Validation
Model update

👉 Directly calls action method

4.ajax="false"

👉 Full page reload (no partial lifecycle)

5.partialSubmit="true"

👉 Sends only changed values → performance boost

6.resetValues="true"

👉 Clears component state after update
*/
 
/*
 * | Phase         | Happens When                |
| ------------- | --------------------------- |
| Apply Request | `process` decides           |
| Validation    | skipped if `immediate=true` |
| Model Update  | setters called              |
| Invoke App    | action method               |
| Render        | `update` decides            |

 */
//AjaxBean.java->ajaxattributes.xhtml
public class AjaxBean {

    private String name;
    private Integer age;

    public void submit() {
        System.out.println("👉 Action Method Called");

        FacesContext.getCurrentInstance().addMessage(null,
            new FacesMessage("Submitted", name + " - " + age));
    }

    public void reset() {
        name = null;
        age = null;
        System.out.println("👉 Reset Called");
    }

    // Getters & Setters
    public String getName() { return name; }

    public void setName(String name) {
        System.out.println("👉 setName()");
        this.name = name;
    }

    public Integer getAge() { return age; }

    public void setAge(Integer age) {
        System.out.println("👉 setAge()");
        this.age = age;
    }
}