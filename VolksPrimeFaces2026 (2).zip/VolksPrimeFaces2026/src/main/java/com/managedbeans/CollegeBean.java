package com.managedbeans;

import java.io.Serializable;
import java.util.Date;

import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;

@Named
@ViewScoped
/*
 * 🔷 Validation Types (in PrimeFaces)
1.Built-in (JSF)
required="true", <f:validateLength>, <f:validateRange>, <f:validateRegex>

2.Bean Validation (Annotations)
@NotNull, @Size, @Email, @Min, @Max

3.Custom Validator
Create using @FacesValidator

4.Client-Side Validation
Runs in browser (faster)

5.AJAX Validation
Real-time validation using <p:ajax>

🔷 Validation Categories

1.Field-level → single field
2.Cross-field → compare multiple fields (e.g., password match)
3.Form-level → whole form rules
4.Business-level → DB/business logic
5.Client vs Server → where validation runs

🔷 Common Rules
Required → required="true"
Length → <f:validateLength>
Range → <f:validateLongRange>
Pattern → <f:validateRegex>
Email → @Email
Date → <p:datePicker>
Custom → business logic

🔷 Lifecycle (in Jakarta Faces)

Process Validations phase

--If fails → stops flow, shows errors, model not updated

🔷 Messages

<p:message for="field"/>
<p:messages/>
 */
//CollegeBean.java->collegevalidation.xhtml

public class CollegeBean implements Serializable {

    private String studentName;
    private String email;
    private String phone;
    public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	
	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public Double getTuitionFee() {
		return tuitionFee;
	}

	public void setTuitionFee(Double tuitionFee) {
		this.tuitionFee = tuitionFee;
	}

	public Double getHostelFee() {
		return hostelFee;
	}

	public void setHostelFee(Double hostelFee) {
		this.hostelFee = hostelFee;
	}

	public Double getTransportFee() {
		return transportFee;
	}

	public void setTransportFee(Double transportFee) {
		this.transportFee = transportFee;
	}

	public Double getDiscount() {
		return discount;
	}

	public void setDiscount(Double discount) {
		this.discount = discount;
	}

	public Double getTotalFee() {
		return totalFee;
	}

	public void setTotalFee(Double totalFee) {
		this.totalFee = totalFee;
	}

	
	private String course;
    private Double tuitionFee;
    private Double hostelFee;
    private Double transportFee;
    private Double discount;
    private Double totalFee;
    
    // Calculate total
    public void calculateTotal() {
        double total = 0;

        if (tuitionFee != null) total += tuitionFee;
        if (hostelFee != null) total += hostelFee;
        if (transportFee != null) total += transportFee;

        if (discount != null) {
            total -= discount;
        }

        totalFee = total;
    }

    // Submit
    public void submit() {
        FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO,
                        "Success", "Student Registered Successfully"));
    }

    // Getters & Setters
    // (Generate using IDE)
    /*
     * In JSF Expression Language (EL):

👉 You DO NOT call methods with is prefix
👉 You access them like properties

| Java Method        | EL Property Name |
| ------------------ | ---------------- |
| `isFormValid()`    | `formValid`      |
| `getTotal()`       | `total`          |
| `getStudentName()` | `studentName`    |

     */
    public boolean isFormValid() {
        if (studentName == null || studentName.trim().isEmpty()) return false;
        if (email == null || email.trim().isEmpty()) return false;
        if (phone == null || !phone.matches("\\d{10}")) return false;
        if (course == null || course.isEmpty()) return false;

        double tuition = tuitionFee != null ? tuitionFee : 0;
        double hostel = hostelFee != null ? hostelFee : 0;
        double transport = transportFee != null ? transportFee : 0;
        double disc = discount != null ? discount : 0;

        if (disc > (tuition + hostel + transport)) return false;//✔ Discount should NOT exceed total fees

        return true;//If all validations pass → form is valid
    }
}