package com.managedbeans;
import jakarta.ws.rs.core.MediaType;

import com.model.FurnitureREST;

import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;

@Named("frestbean")
@RequestScoped
public class FurnitureRESTBean {

	  private FurnitureREST furniture = new FurnitureREST();

	    private String response;

	    public void save() {

	        // 🔢 calculation
	        double total = furniture.getQuantity() * furniture.getPrice();
	        furniture.setTotal(total);

	        double discount = total > 4000 ? total * 0.10 : total * 0.05;
	        furniture.setDiscount(discount);

	        furniture.setFinalAmount(total - discount);

	        // 🌐 call JSON SERVER
	        Client client = ClientBuilder.newClient();

	        WebTarget target = client.target("http://localhost:3000/furniture");

	        response = target.request(MediaType.APPLICATION_JSON)
	                .post(Entity.json(furniture), String.class);
	    }

	    public String getResponse() {
	        return response;
	    }

	    public FurnitureREST getFurniture() {
	        return furniture;
	    }
}
