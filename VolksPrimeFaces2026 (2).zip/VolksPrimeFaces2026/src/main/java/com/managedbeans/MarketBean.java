package com.managedbeans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.model.Item;

import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;

@Named("marketBean11")
@ViewScoped
/*
 * 
<!-- Layout & Structure
PrimeFlex (grid, col-*)
👉 Responsive layout (left menu + right content)
panel
👉 Section container (Dashboard, Billing, Reports)
panelGrid
👉 Form layout (label + input in grid style)
outputPanel
👉 Dynamic content container updated via AJAX -->
 */
//Item.java->MarketBean.java->supermarket.xhtml

public class MarketBean implements Serializable {

    private String page = "dashboard";

    private String product;
    private double price;
    private int qty;
    private double discountPercent;

    private double gst;
    private double discountAmount;
    private double total;
    private double profit;

    private List<Item> items = new ArrayList<>();

    private double subTotal;
    private double totalGST;
    private double grandTotal;
    private double totalSales;

    public void setPage(String page) {
        this.page = page;
    }

    public String getPage() {
        return page;
    }

    // 🔹 Calculation logic
    public void calculate() {
        double base = price * qty;

        gst = base * 0.05;
        discountAmount = base * (discountPercent / 100);
        total = base + gst - discountAmount;
        profit = total * 0.10;
    }

    public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public double getDiscountPercent() {
		return discountPercent;
	}

	public void setDiscountPercent(double discountPercent) {
		this.discountPercent = discountPercent;
	}

	public double getGst() {
		return gst;
	}

	public void setGst(double gst) {
		this.gst = gst;
	}

	public double getDiscountAmount() {
		return discountAmount;
	}

	public void setDiscountAmount(double discountAmount) {
		this.discountAmount = discountAmount;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public double getProfit() {
		return profit;
	}

	public void setProfit(double profit) {
		this.profit = profit;
	}

	public List<Item> getItems() {
		return items;
	}

	public void setItems(List<Item> items) {
		this.items = items;
	}

	public double getSubTotal() {
		return subTotal;
	}

	public void setSubTotal(double subTotal) {
		this.subTotal = subTotal;
	}

	public double getTotalGST() {
		return totalGST;
	}

	public void setTotalGST(double totalGST) {
		this.totalGST = totalGST;
	}

	public double getGrandTotal() {
		return grandTotal;
	}

	public void setGrandTotal(double grandTotal) {
		this.grandTotal = grandTotal;
	}

	public double getTotalSales() {
		return totalSales;
	}

	public void setTotalSales(double totalSales) {
		this.totalSales = totalSales;
	}

	// 🔹 Add to cart
    public void addItem() {
        Item item = new Item(product, qty, total);
        items.add(item);

        subTotal += price * qty;
        totalGST += gst;
        grandTotal += total;
        totalSales += total;

        product = "";
        price = 0;
        qty = 0;
        discountPercent = 0;
    }

    // getters/setters
}