package com.managedbeans;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.model.CartItem;

import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;

@Named
@ViewScoped
public class ShopBean implements Serializable {

    private String productName;
    private Double price;
    private Integer quantity;

    private List<CartItem> cart = new ArrayList<>();

    private String customerName;
    private String address;

    // Add product
    public void addProduct() {
    	 System.out.println("Adding product...");
         System.out.println(productName + " | " + price + " | " + quantity);

         if (productName != null && price != null && quantity != null) {
             cart.add(new CartItem(productName, price, quantity));
         }

         // reset fields
         productName = "";
         price = null;
         quantity = null;
     
    }

    
    // Remove product
    public void removeProduct(CartItem item) {
        cart.remove(item);
    }
//JAVA STREAM API
    // Grand total
    public double getGrandTotal() {
        return cart.stream().mapToDouble(CartItem::getTotal).sum();
    }
/*
 * double total = 0;
for (CartItem item : cart) {
    total += item.getTotal();
}
return total;
 */
    public void setCart(List<CartItem> cart) {
		this.cart = cart;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	  public String placeOrder() {

	        String message = "🎉 Order placed successfully! Thank you, " + customerName;

	        FacesContext.getCurrentInstance().addMessage(null,
	            new FacesMessage(FacesMessage.SEVERITY_INFO, message, null));

	        cart.clear();

	        // reset fields
	        customerName = "";
	        address = "";

	        return null;
	    }

    // Getters & Setters

    public List<CartItem> getCart() {
        return cart;
    }

    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }

    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
}