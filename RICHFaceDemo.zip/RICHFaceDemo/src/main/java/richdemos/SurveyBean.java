package richdemos;

import java.io.Serializable;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

@ManagedBean(name = "surveyBean")
@ViewScoped
public class SurveyBean implements Serializable {

    private String voterName;
    private String ageGroup;
    private String district;
    private boolean agreeTerms;
    private String candidate;

    private int countA;
    private int countB;
    private int countC;

    private int totalVotes;
    private double percentA;
    private double percentB;
    private double percentC;
    String resultMessage;
    public void calculate() {
    	
		if ("A".equals(candidate)) {
            countA++;
            resultMessage = "You selected Candidate A";
        } else if ("B".equals(candidate)) {
            countB++;
            resultMessage = "You selected Candidate B";
        } else if ("C".equals(candidate)) {
            countC++;
            resultMessage = "You selected Candidate C";
        }

        totalVotes = countA + countB + countC;

        if (totalVotes > 0) {
            percentA = (countA * 100.0) / totalVotes;
            percentB = (countB * 100.0) / totalVotes;
            percentC = (countC * 100.0) / totalVotes;
        } else {
            percentA = percentB = percentC = 0;
        }
    }
    public String getResultMessage() { return resultMessage; }
    public String getVoterName() {
        return voterName;
    }

    public void setVoterName(String voterName) {
        this.voterName = voterName;
    }

    public String getAgeGroup() {
        return ageGroup;
    }

    public void setAgeGroup(String ageGroup) {
        this.ageGroup = ageGroup;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public boolean isAgreeTerms() {
        return agreeTerms;
    }

    public void setAgreeTerms(boolean agreeTerms) {
        this.agreeTerms = agreeTerms;
    }

    public String getCandidate() {
        return candidate;
    }

    public void setCandidate(String candidate) {
        this.candidate = candidate;
    }

    public int getCountA() {
        return countA;
    }

    public void setCountA(int countA) {
        this.countA = countA;
    }

    public int getCountB() {
        return countB;
    }

    public void setCountB(int countB) {
        this.countB = countB;
    }

    public int getCountC() {
        return countC;
    }

    public void setCountC(int countC) {
        this.countC = countC;
    }

    public int getTotalVotes() {
        return totalVotes;
    }

    public double getPercentA() {
        return percentA;
    }

    public double getPercentB() {
        return percentB;
    }

    public double getPercentC() {
        return percentC;
    }
}