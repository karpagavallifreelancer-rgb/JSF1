package richdemos;

import java.io.Serializable;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

@ManagedBean(name = "garmentBean")
@ViewScoped
public class GarmentBean implements Serializable {

    private String customerName;
    private String garmentType;
    private String size;
    private String color;
    private int quantity;

    private boolean embroidery;
    private boolean expressDelivery;

    private double unitPrice;
    private double embroideryCharge;
    private double deliveryCharge;
    private double subtotal;
    private double tax;
    private double discount;
    private double total;

    public void calculate() {
        if ("Shirt".equals(garmentType)) {
            unitPrice = 800;
        } else if ("Pant".equals(garmentType)) {
            unitPrice = 1200;
        } else if ("Kurti".equals(garmentType)) {
            unitPrice = 1000;
        } else {
            unitPrice = 0;//If nothing is selected, price becomes 0.
        }

        embroideryCharge = embroidery ? 150 : 0;//If embroidery is checked, add 150. Otherwise add 0.
        deliveryCharge = expressDelivery ? 200 : 100;//If express delivery is checked, charge 200. Otherwise charge 100.

        subtotal = (unitPrice * quantity) + embroideryCharge;//Calculates item cost plus embroidery charge.
        tax = subtotal * 0.05;//Adds 5% tax on subtotal.
        discount = subtotal > 5000 ? subtotal * 0.1 : 0;//Gives 10% discount if subtotal is above 5000.
        total = subtotal + tax + deliveryCharge - discount;
    }

    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }

    public String getGarmentType() { return garmentType; }
    public void setGarmentType(String garmentType) { this.garmentType = garmentType; }

    public String getSize() { return size; }
    public void setSize(String size) { this.size = size; }

    public String getColor() { return color; }
    public void setColor(String color) { this.color = color; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public boolean isEmbroidery() { return embroidery; }
    public void setEmbroidery(boolean embroidery) { this.embroidery = embroidery; }

    public boolean isExpressDelivery() { return expressDelivery; }
    public void setExpressDelivery(boolean expressDelivery) { this.expressDelivery = expressDelivery; }

    public double getUnitPrice() { return unitPrice; }
    public double getEmbroideryCharge() { return embroideryCharge; }
    public double getDeliveryCharge() { return deliveryCharge; }
    public double getSubtotal() { return subtotal; }
    public double getTax() { return tax; }
    public double getDiscount() { return discount; }
    public double getTotal() { return total; }
}