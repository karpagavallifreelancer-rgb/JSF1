package richdemos;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

@ManagedBean(name = "categoryBean")
@ViewScoped
public class CategoryBean implements Serializable {

    private String category;
    private String subCategory;
    private String debugMessage;

    public List<String> getCategories() {
        return Arrays.asList("Electronics", "Garments", "Books");
    }

    public List<String> getSubCategories() {
        if ("Electronics".equals(category)) {
            return Arrays.asList("Mobile", "Laptop", "TV");
        } else if ("Garments".equals(category)) {
            return Arrays.asList("Shirt", "Pant", "Kurti");
        } else if ("Books".equals(category)) {
            return Arrays.asList("Java", "JSF", "RichFaces");
        }
        return Arrays.asList("Select Category First");
    }

    public void onCategoryChange() {
        subCategory = null;
        debugMessage = "Category changed to: " + category + " | Subcategory reset";
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(String subCategory) {
        this.subCategory = subCategory;
        debugMessage = "Subcategory selected: " + subCategory;
    }

    public String getDebugMessage() {
        return debugMessage;
    }
}