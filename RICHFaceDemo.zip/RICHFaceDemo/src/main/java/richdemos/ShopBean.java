package richdemos;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

@ManagedBean(name = "shopBean")//Accessible in XHTML
@ViewScoped
//Product.java->ShopBean.java->shopping.xhtml

public class ShopBean implements Serializable {

    private String customerName;
    private String deliveryType = "STANDARD";
    private boolean giftWrap;
    private String category = "Mobiles";

    private List<Product> products;

    private double subtotal;
    private double deliveryCharge;
    private double giftWrapCharge;
    private double total;

    public ShopBean() {
        products = new ArrayList<>();
        products.add(new Product("Mobile Phone", 15000));
        products.add(new Product("Laptop", 55000));
        products.add(new Product("Headphones", 2500));
        products.add(new Product("Smart Watch", 7000));
        products.add(new Product("Tablet", 22000));
    }

    public void calculate() {
        subtotal = 0;

        for (Product p : products) {
            if (p.isSelected()) //Checks whether the customer selected that product.
            {
            	//Adds the product’s price multiplied by quantity to the subtotal.
                subtotal += p.getPrice() * p.getQuantity();
            }
        }
/*
 * Sets delivery charge to:

200 if delivery type is EXPRESS

100 otherwise
 */
        deliveryCharge = "EXPRESS".equals(deliveryType) ? 200 : 100;
        giftWrapCharge = giftWrap ? 50 : 0;//Adds a 50 gift wrap charge if gift wrap is checked, otherwise 0.
        //selected item total + delivery fee + gift wrap fee = grand total.
        total = subtotal + deliveryCharge + giftWrapCharge;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getDeliveryType() {
        return deliveryType;
    }

    public void setDeliveryType(String deliveryType) {
        this.deliveryType = deliveryType;
    }

    public boolean isGiftWrap() {
        return giftWrap;
    }

    public void setGiftWrap(boolean giftWrap) {
        this.giftWrap = giftWrap;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public List<Product> getProducts() {
        return products;
    }

    public double getSubtotal() {
        return subtotal;
    }

    public double getDeliveryCharge() {
        return deliveryCharge;
    }

    public double getGiftWrapCharge() {
        return giftWrapCharge;
    }

    public double getTotal() {
        return total;
    }
}