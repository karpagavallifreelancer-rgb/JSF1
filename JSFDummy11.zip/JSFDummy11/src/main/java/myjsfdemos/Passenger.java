package myjsfdemos;

public class Passenger {

    private String name;
    private int age;
    private String seatNo;

    public Passenger(String name, int age, String seatNo) {
        this.name = name;
        this.age = age;
        this.seatNo = seatNo;
    }

    public String getName() { return name; }
    public int getAge() { return age; }
    public String getSeatNo() { return seatNo; }
}