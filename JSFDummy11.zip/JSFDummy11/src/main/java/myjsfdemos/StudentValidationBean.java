package myjsfdemos;

import java.time.LocalDate;
import java.util.Date;

import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

/*
 * 1. JSF UI-Level Validation

👉 Defined in .xhtml

✔ Characteristics
Runs during JSF lifecycle (Process Validations phase)
Happens before data reaches the bean
Stops further validation if it fails
Good for UI-specific checks

2. Bean Validation (Annotation-Based)

👉 Defined in Java class

✔ Characteristics
Runs after JSF UI validation
Happens when model (bean) is updated
Good for business rules / reusable validation
Works across layers (JSF, REST, DB)

PRIORITY ORDER (VERY IMPORTANT)
✅ Execution Flow:
1. JSF UI Validation (required, f:validateXXX)
        ↓
2. If PASSED →
3. Bean Validation (@NotNull, @Min, etc.)
        ↓
4. If PASSED →
5. Invoke action method

👉 JSF UI validation has HIGHER PRIORITY

👉 Do NOT mix both for same field
 */
/*
 * JSF UI vs Bean Validation in Jakarta Faces::
 * 
🔹 JSF UI Validation::::::::::
Defined in XHTML
Examples: required="true", <f:validateLongRange>
Runs FIRST
Stops further validation if fails

🔹 Bean Validation::::::::::::::::::
Defined in Java (@NotNull, @Min, etc.)
Runs AFTER JSF validation
Executes only if UI validation passes

⚡ PRIORITY

1. JSF Validation (HIGH priority)
2. Bean Validation
3. Action method

🎯 KEY POINT

👉 If JSF validation fails → Bean Validation won’t run

✅ BEST PRACTICE

✔ Use Bean Validation only (avoid mixing)

🧠 ONE-LINE MEMORY

👉 JSF = UI check | Bean = Business check
 */

//StudentValidationBean.java=>ValidBirthDate.java=>BirthDateValidator.java=>universityvalidation.xhtml


@Named("studentValidBean")
@RequestScoped
public class StudentValidationBean {
//👉 Remove required="true" when using @NotNull
    @NotNull(message="Name required")
    @Size(min=3, message="Name must be at least 3 characters")
    private String name;

    public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getStudentId() {
		return studentId;
	}

	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}

	public Integer getMaths() {
		return maths;
	}

	public void setMaths(Integer maths) {
		this.maths = maths;
	}

	public Integer getPhysics() {
		return physics;
	}

	public void setPhysics(Integer physics) {
		this.physics = physics;
	}

	public Integer getChemistry() {
		return chemistry;
	}

	public void setChemistry(Integer chemistry) {
		this.chemistry = chemistry;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public double getPercentage() {
		return percentage;
	}

	public void setPercentage(double percentage) {
		this.percentage = percentage;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	@NotNull(message="Age required")
    @Min(value=17, message="Minimum age is 17")
    @Max(value=30, message="Maximum age is 30")
    private Integer age;

    @NotNull(message="Email required")
    @Email(message="Invalid email format")
    private String email;

    @NotNull(message="Phone required")
    @Pattern(regexp="^[0-9]{10}$", message="Phone must be 10 digits")
    private String phone;

    @NotNull(message="Student ID required")
    @Pattern(regexp="UNI\\d{4}", message="Format: UNI1234")
    private String studentId;

    @NotNull(message="Maths marks required")
    @Min(value=0, message="Min 0")
    @Max(value=100, message="Max 100")
    private Integer maths;

    @NotNull(message="Physics marks required")
    @Min(value=0, message="Min 0")
    @Max(value=100, message="Max 100")
    private Integer physics;

    @NotNull(message="Chemistry marks required")
    @Min(value=0, message="Min 0")
    @Max(value=100, message="Max 100")
    private Integer chemistry;

    /*
     * JSF requiredMessage takes priority
     * 
     * WHY?

In Jakarta Faces lifecycle:

JSF required="true" runs FIRST
If empty → validation stops there ❗
Bean Validation (@NotNull) is NOT executed

| Case                               | Message Shown             |
| ---------------------------------- | ------------------------- |
| Field empty + `required="true"`    | ✅ `requiredMessage`       |
| Field empty + NO `required="true"` | ✅ `@NotNull` message      |
| Field has value but invalid        | ✅ Bean Validation message |

👉 JSF required = UI level
👉 @NotNull = backend level
     */
    @NotNull(message="Course required")
    private String course;

    @NotNull(message="Address required")
    @Size(min=5, message="Address too short")
    private String address;
    
    @NotNull(message="Birthdate required")
    @ValidBirthDate//Custom validation annotation.
    private Date birthDate;

    public Date getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	private int total;
    private double percentage;
    private String result;

    public void calculate() {

        total = maths + physics + chemistry;
        percentage = total / 3.0;

        // ✅ CROSS-FIELD VALIDATION (Eligibility)
        if (percentage >= 60 && age >= 18) {
            result = "Eligible for Admission";
        } else {
            result = "Not Eligible";
        }
    }

    // Getters & Setters
}