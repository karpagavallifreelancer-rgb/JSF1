package myjsfdemos;

import java.io.Serializable;

/*
 * Model Bean::
 * 
Holds data (POJO)
Getter/Setter methods
 */
/*
 * Employee.java->EmployeeBean.java->employee.xhtml->employee_result.xhtml
 */
public class Employee implements Serializable {
    private String name;
    private String department;
    private double salary;

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    public double getSalary() { return salary; }
    public void setSalary(double salary) { this.salary = salary; }
}