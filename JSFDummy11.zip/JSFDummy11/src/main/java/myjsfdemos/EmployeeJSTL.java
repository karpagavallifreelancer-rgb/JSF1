package myjsfdemos;

/*
 * 
 * JSTL Usage in Jakarta Faces 4:::
Mainly used in Facelets (.xhtml pages)
Works with Expression Language (EL) like: #{bean.name}

Common namespace:
xmlns:c="http://java.sun.com/jsp/jstl/core"
xmlns:fmt="http://java.sun.com/jsp/jstl/fmt"
xmlns:fn="http://java.sun.com/jsp/jstl/functions"

⚡ Quick Summary
Category	Prefix	Purpose
Core	c:	Logic + loops
Formatting	fmt:	Date & number
XML	x:	XML handling
SQL	sql:	Database
Functions	fn:	String utilities
 * 
 * 
 * 🚫 JSTL LIMITATIONS (Short)
❌ Runs only once (build time)
→ Does not update after user actions
❌ Not JSF lifecycle aware
→ May show old/incorrect data
❌ Poor integration with JSF beans
→ EL evaluated early, not at runtime
❌ Breaks JSF component tree
→ Components may not render/validate properly
❌ Limited EL support
→ Complex logic/method calls unreliable
❌ No AJAX support
→ Cannot re-render UI dynamically
❌ c:forEach is static
→ Not suitable for JSF UI components


✅ BEST PRACTICE
Use JSF instead of JSTL:
<c:if> ❌ → rendered ✅
<c:forEach> ❌ → <h:dataTable> / <ui:repeat> ✅


👉 JSTL is not suitable for JSF dynamic UI because it runs at build time and is not lifecycle-aware.

In Jakarta Faces (JSF):

JSTL runs at view build time
JSF components run at runtime

✔️ So for dynamic UI updates, prefer:

<h:dataTable>
<h:repeat>
 */
//model class

import java.io.Serializable;

//JSTL MODEL/ENTITY CLASS
public class EmployeeJSTL implements Serializable {

    private String name;
    private String pan;
    private double basicSalary;
    private double allowance;
    private double deduction;
    private double gstRate;

    private boolean panValid;
    private double netSalary;

    public void calculate() {

        if (pan == null || !pan.matches("[A-Z]{5}[0-9]{4}[A-Z]{1}")) {
        	  panValid = false;
            netSalary = 0;
            return;
        }
        panValid = true;
        double gross = basicSalary + allowance;
        double gst = (gross * gstRate) / 100;

        netSalary = gross - gst - deduction;
    }
    

    public boolean isPanValid() {
        return panValid;
    }

    public void setPanValid(boolean panValid) {
        this.panValid = panValid;
    }

    // Getters & Setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getPan() { return pan; }
    public void setPan(String pan) { this.pan = pan; }

    public double getBasicSalary() { return basicSalary; }
    public void setBasicSalary(double basicSalary) { this.basicSalary = basicSalary; }

    public double getAllowance() { return allowance; }
    public void setAllowance(double allowance) { this.allowance = allowance; }

    public double getDeduction() { return deduction; }
    public void setDeduction(double deduction) { this.deduction = deduction; }

    public double getGstRate() { return gstRate; }
    public void setGstRate(double gstRate) { this.gstRate = gstRate; }

    public double getNetSalary() { return netSalary; }
}