package myjsfdemos;

import jakarta.inject.Named;
import jakarta.enterprise.context.RequestScoped;

/*
 * | Scope             | Lifetime       | Data Persistence | Use Case       |
| ----------------- | -------------- | ---------------- | -------------- |
| RequestScoped     | Single request | ❌ No             | Form submit    |
| ViewScoped        | Same page      | ⚠️ Limited       | UI interaction |
| SessionScoped     | User session   | ✅ Yes            | Cart/Login     |
| ApplicationScoped | Entire app     | ✅ Shared         | Global data    |
| Dependent         | Temporary      | ❌ No             | Helper logic   |

👉 Request = 1 request
👉 View = 1 page
👉 Session = 1 user
👉 Application = all users

📦 SCOPES IN JSF / CDI (SHORT)

1. @RequestScoped
Lives: 1 request
Data: resets every click
Use: simple forms
❌ Not for cart

2. @ViewScoped
Lives: same page
Data: preserved in one page
Use: cart, invoice pages
⚠️ Must implement Serializable

3. @SessionScoped
Lives: whole user session
Data: shared across pages
Use: login, shopping cart
⚠️ Must implement Serializable

4. @ApplicationScoped
Lives: whole application
Data: shared by all users
Use: config, GST rates, constants
⚠️ Must be thread-safe

5. @Dependent
Lives: only during injection
Use: helper/utility beans

⚠️ IMPORTANT RULES

✔ Serializable required
ViewScoped
SessionScoped

✔ Use correct scope
Cart → ViewScoped / SessionScoped
Config → ApplicationScoped
Form → RequestScoped

❌ Avoid
RequestScoped for multi-step/cart apps
Storing user data in ApplicationScoped
 */
@Named("studentBean")
@RequestScoped
public class StudentBean {

    private String name;
    private String message;
/*
 * Backing Bean:::
 * 
Directly linked to UI (JSF pages)
Handles actions/events
 */
    public String submit() {
        message = "Welcome " + name;
        return "result.xhtml";
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMessage() {
        return message;
    }

	public void setMessage(String message) {
		this.message = message;
	}
	
}