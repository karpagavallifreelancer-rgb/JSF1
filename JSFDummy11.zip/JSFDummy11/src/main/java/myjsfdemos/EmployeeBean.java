package myjsfdemos;

import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;

@Named
@RequestScoped
public class EmployeeBean {

    private Employee employee = new Employee();

    public Employee getEmployee() {
        return employee;
    }

    public String submit() {
        System.out.println("✔ Action method invoked: Employee submitted");
        return "employee_result.xhtml";
    }
}