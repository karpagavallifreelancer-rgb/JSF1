package myjsfdemos;

import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
@Named("employeebeanjstl")
@SessionScoped

//EmployeeJSTL.java->EmployeeJSTLBean.java->JSTLEmployeeSalarySlip.xhtml

public class EmployeeJSTLBean implements Serializable {

    private EmployeeJSTL employee = new EmployeeJSTL();
    private List<EmployeeJSTL> employeeList = new ArrayList<>();

    public void addEmployee() {

        employee.calculate();   // calculate salary
        employeeList.add(employee);

        employee = new EmployeeJSTL(); // reset form
    }

    public List<EmployeeJSTL> getEmployeeList() {
        return employeeList;
    }

    public EmployeeJSTL getEmployee() {
        return employee;
    }

    public void setEmployee(EmployeeJSTL employee) {
        this.employee = employee;
    }
}