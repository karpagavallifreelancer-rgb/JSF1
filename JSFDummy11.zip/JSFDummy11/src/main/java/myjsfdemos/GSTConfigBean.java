package myjsfdemos;

import java.util.HashMap;
import java.util.Map;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;

@Named
@ApplicationScoped//ApplicationScoped = ONE object for entire application (all users share same data)
/*
 * ApplicationScoped behavior:::
Same bean instance for ALL users
Shared memory object

✔ Real-world use cases

✔ GST billing system
✔ Inventory pricing system
✔ Shared configuration system

❗ Why NOT use ApplicationScoped for cart?

Because:

Data will be shared between all users ❌
Not user-specific ❌

👉 Correct scope = @SessionScoped

👉 Good for:

GST rules
Global tax rates
App settings
 */
public class GSTConfigBean {

    private Map<String, Double> stateGstMap = new HashMap<>();

    public GSTConfigBean() {
        stateGstMap.put("Tamil Nadu", 0.18);
        stateGstMap.put("Karnataka", 0.18);
        stateGstMap.put("Delhi", 0.18);
        stateGstMap.put("Other", 0.18);
    }

    public double getGstRate(String state) {
        return stateGstMap.getOrDefault(state, 0.18);
    }
}