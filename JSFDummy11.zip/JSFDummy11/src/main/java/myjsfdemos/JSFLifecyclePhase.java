package myjsfdemos;

import jakarta.faces.event.PhaseEvent;
import jakarta.faces.event.PhaseId;
import jakarta.faces.event.PhaseListener;

public class JSFLifecyclePhase implements PhaseListener {

    @Override
    public void afterPhase(PhaseEvent event) {
        System.out.println("AFTER PHASE: " + event.getPhaseId());
    }

    @Override
    public void beforePhase(PhaseEvent event) {
        System.out.println("BEFORE PHASE: " + event.getPhaseId());
    }

    @Override
    public PhaseId getPhaseId() {
        return PhaseId.ANY_PHASE;
    }
}