package myjsfdemos;
/*
 * | Scope             | Correct Package                              |
| ----------------- | -------------------------------------------- |
| ViewScoped        | jakarta.faces.view.ViewScoped                |
| SessionScoped     | jakarta.enterprise.context.SessionScoped     |
| RequestScoped     | jakarta.enterprise.context.RequestScoped     |
| ApplicationScoped | jakarta.enterprise.context.ApplicationScoped |

 */
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Named("railBean")
@ViewScoped
//Passenger.java->RailTemplateBean.java->templateheader.xhtml->templatefooter.xhtml->templaterailbooking.xtml
//templatedemo.xhtml
public class RailTemplateBean implements Serializable {

    private String trainName;
    private String travelClass;

    private String passengerName;
    private int age;
    private String seatNo;

    private List<Passenger> passengers = new ArrayList<>();

    private double baseFare = 500;
    private double total;
    private String result;

    // ADD PASSENGER
    public void addPassenger() {
        passengers.add(new Passenger(passengerName, age, seatNo));
        passengerName = "";
        age = 0;
        seatNo = "";
    }

    // CALCULATE
    public void calculate() {

        total = 0;

        for (Passenger p : passengers) {
            double fare = baseFare;
/*
 * | Class   | Fare |
| ------- | ---- |
| Sleeper | ₹500 |
| AC      | ₹800 |

 */
            // seat class logic
            if ("AC".equals(travelClass)) {
                fare += 300;//AC adds ₹300 extra
            }

            // age discount
            if (p.getAge() < 12) {
                fare *= 0.5;//50% discount Child pays half fare
            } else if (p.getAge() > 60) {
                fare *= 0.7;//30% discount Senior pays 70% only
            }

            total += fare;
        }

        result = "Train: " + trainName +
                 ", Passengers: " + passengers.size() +
                 ", Final Amount: ₹" + total;
    }

    // getters & setters
    public String getTrainName() { return trainName; }
    public void setTrainName(String trainName) { this.trainName = trainName; }

    public String getTravelClass() { return travelClass; }
    public void setTravelClass(String travelClass) { this.travelClass = travelClass; }

    public String getPassengerName() { return passengerName; }
    public void setPassengerName(String passengerName) { this.passengerName = passengerName; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }

    public String getSeatNo() { return seatNo; }
    public void setSeatNo(String seatNo) { this.seatNo = seatNo; }

    public List<Passenger> getPassengers() { return passengers; }

    public String getResult() { return result; }
}