package myjsfdemos;
import java.util.Calendar;
import java.util.Date;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class BirthDateValidator implements ConstraintValidator<ValidBirthDate, Date> {

    @Override
    public boolean isValid(Date value, ConstraintValidatorContext context) {

        if (value == null) return true;

        Date today = new Date();

        if (value.after(today)) {
            return false;
        }

        Calendar dob = Calendar.getInstance();
        dob.setTime(value);

        Calendar now = Calendar.getInstance();

        int age = now.get(Calendar.YEAR) - dob.get(Calendar.YEAR);

        if (now.get(Calendar.DAY_OF_YEAR) < dob.get(Calendar.DAY_OF_YEAR)) {
            age--;
        }

        return age >= 18;
    }
}