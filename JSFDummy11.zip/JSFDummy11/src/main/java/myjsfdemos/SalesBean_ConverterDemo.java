package myjsfdemos;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;

import java.time.LocalTime;
import java.util.Date;
/*
 * 1. Standard / Built-in Converters

Provided by JSF.

Common converters:

<f:convertNumber>
<f:convertDateTime>
<f:converter converterId="jakarta.faces.Integer">
<f:converter converterId="jakarta.faces.Double">
<f:converter converterId="jakarta.faces.Boolean">
<f:converter converterId="jakarta.faces.Enum">

2. Number Converters

Used for integer, currency, percentage, decimal formatting.

3. Date & Time Converters

Used for date, time, datetime formatting.

Rules:

Converter runs before validation
If conversion fails, validation will not run
Use converter for datatype conversion only
Use validator for rules like min, max, regex

Execution Order::

1. Conversion
2. Validation
3. Bean update
4. Action method

| Feature                   | Converter        | Validator     |
| ------------------------- | ---------------- | ------------- |
| Purpose                   | Type conversion  | Rule checking |
| Example                   | String → Integer | Age 18–30     |
| Runs First?               | Yes              | No            |
| Failure Stops Validation? | Yes              | Yes           |


Converter = datatype change
Validator = rule checking
 */


@Named("salesBean")
@RequestScoped

//SalesBean_ConverterDemo.java->salesconverterdemo.xhtml
public class SalesBean_ConverterDemo {

    private String productName;
    private Integer quantity;
    private Double unitPrice;
    private Integer discountPercent;
    private Integer gstPercent;

    private Date purchaseDate;
    public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(Double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public Integer getDiscountPercent() {
		return discountPercent;
	}

	public void setDiscountPercent(Integer discountPercent) {
		this.discountPercent = discountPercent;
	}

	public Integer getGstPercent() {
		return gstPercent;
	}

	public void setGstPercent(Integer gstPercent) {
		this.gstPercent = gstPercent;
	}

	public Date getPurchaseDate() {
		return purchaseDate;
	}

	public void setPurchaseDate(Date purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	public LocalTime getDeliveryTime() {
		return deliveryTime;
	}

	public void setDeliveryTime(LocalTime deliveryTime) {
		this.deliveryTime = deliveryTime;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Double getSubTotal() {
		return subTotal;
	}

	public void setSubTotal(Double subTotal) {
		this.subTotal = subTotal;
	}

	public Double getDiscountAmount() {
		return discountAmount;
	}

	public void setDiscountAmount(Double discountAmount) {
		this.discountAmount = discountAmount;
	}

	public Double getGstAmount() {
		return gstAmount;
	}

	public void setGstAmount(Double gstAmount) {
		this.gstAmount = gstAmount;
	}

	public Double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}

	private LocalTime deliveryTime;
    private String status;

    private Double subTotal;
    private Double discountAmount;
    private Double gstAmount;
    private Double totalAmount;

    public void calculate() {

        subTotal = quantity * unitPrice;

        discountAmount = subTotal * discountPercent / 100.0;

        double afterDiscount = subTotal - discountAmount;

        gstAmount = afterDiscount * gstPercent / 100.0;

        totalAmount = afterDiscount + gstAmount;
    }

    // Getters and Setters
}