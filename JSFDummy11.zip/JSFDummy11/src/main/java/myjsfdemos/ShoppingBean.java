package myjsfdemos;

import jakarta.inject.Named;
import jakarta.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Named("shopBean")
@SessionScoped
//ShoppingBean.java->products.xhtml->cart.xhtml->checkout.xhtml->confirm.xhtml
public class ShoppingBean implements Serializable {

    // Product selection
    private String selectedProduct;
    private int quantity;

    // Cart
    private List<String> cart = new ArrayList<>();

    // Customer details (many fields)
    private String name;
    private String email;
    private String address;
    private String city;
    private String paymentMethod;

 // PRICE MAP (simple logic)
    public double getProductPrice(String product) {
        return switch (product) {
            case "Laptop" -> 50000;
            case "Mobile" -> 20000;
            case "Headphones" -> 2000;
            default -> 0;
        };
    }
    /*// ADD TO CART
    public String addToCart() {
        cart.add(selectedProduct + " - Qty: " + quantity);
        return "cart?faces-redirect=true";
    }*/
 // ADD TO CART (UPDATED with price)
    public String addToCart() {
        double price = getProductPrice(selectedProduct);
        double itemTotal = price * quantity;

        cart.add(selectedProduct +
                " | Qty: " + quantity +
                " | Price: " + price +
                " | Subtotal: " + itemTotal);

        return "cart?faces-redirect=true";
    }

 // TOTAL CART VALUE
    public double getCartTotal() {
        double total = 0;

        for (String item : cart) {
            // extract subtotal from string
            if (item.contains("Subtotal:")) {
                String value = item.substring(item.lastIndexOf("Subtotal:") + 10).trim();
                total += Double.parseDouble(value);
            }
        }
        return total;
    }
    // GO TO CHECKOUT
    public String goToCheckout() {
        return "checkout?faces-redirect=true";
    }

    // PLACE ORDER
    public String placeOrder() {
        return "confirm?faces-redirect=true";
    }

    // RESET SESSION (after order)
    public String reset() {
        cart.clear();
        name = email = address = city = paymentMethod = null;
        return "products?faces-redirect=true";
    }

    // GETTERS & SETTERS
    public String getSelectedProduct() { return selectedProduct; }
    public void setSelectedProduct(String selectedProduct) { this.selectedProduct = selectedProduct; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public List<String> getCart() { return cart; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }

    public String getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(String paymentMethod) { this.paymentMethod = paymentMethod; }
}