package myjsfdemos;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;


import org.json.JSONArray;
import org.json.JSONObject;

/*
 * REST API means getting or sending data between JSF UI and backend/external service using HTTP.
 * 
 * JSF Page → REST API → JSON Data
 * 
 * Why REST API is Used??
 * 
Connect JSF with external systems
Get live data from backend/database
Send form data to server
Integrate with mobile/web apps
Separate UI and business logic

| Type        | Purpose              |
| ----------- | -------------------- |
| Public API  | External service     |
| Private API | Internal company use |
| Partner API | Shared with partners |
| CRUD API    | Database operations  |

How JSF Uses REST API

Usually with:

HttpURLConnection
HttpClient
JAX-RS Client
JSON libraries

Rules / Best Practices::

Keep REST logic in service class, not XHTML
Use JSON for request/response
Use GET for fetch, POST for insert
Handle API errors properly
Keep API URL configurable
Parse JSON into Java objects
Do not write API logic directly inside JSF page

JSF does NOT include:

JSON parser
REST client
HTTP libraries

So you must add them manually.
 */
//User_RestAPI.java->JSFRESTAPIDEMO.java->jsfrestapidemo.xhtml
@Named("studentApiBean")
@RequestScoped
public class JSFRESTAPIDEMO {
	  private List<User_RestAPI> users;

	    public void loadStudentData() {

	        try {
	            URL url = new URL("https://jsonplaceholder.typicode.com/users");

	            HttpURLConnection con = (HttpURLConnection) url.openConnection();
	            con.setRequestMethod("GET");

	            BufferedReader br = new BufferedReader(
	                    new InputStreamReader(con.getInputStream())
	            );

	            StringBuilder sb = new StringBuilder();
	            String line;

	            while ((line = br.readLine()) != null) {
	                sb.append(line);
	            }

	            JSONArray array = new JSONArray(sb.toString());

	            users = new ArrayList<>();

	            for (int i = 0; i < array.length(); i++) {

	                JSONObject obj = array.getJSONObject(i);

	                users.add(new User_RestAPI(
	                        obj.getInt("id"),
	                        obj.getString("name"),
	                        obj.getString("username"),
	                        obj.getString("email")
	                ));
	            }

	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	    public List<User_RestAPI> getUsers() {
	        return users;
	    }
}