package myjsfdemos;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.component.UIComponent;
import jakarta.faces.context.FacesContext;
import jakarta.faces.validator.*;

@FacesValidator("studentIdValidator")
public class StudentIdValidator implements Validator<String> {

    @Override
    public void validate(FacesContext context, UIComponent component, String value)
            throws ValidatorException {

        if (!value.matches("UNI\\d{4}")) {
            throw new ValidatorException(
                new FacesMessage(FacesMessage.SEVERITY_ERROR,
                "Invalid ID (Format: UNI1234)", null));
        }
    }
}