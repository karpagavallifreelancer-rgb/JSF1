package myjsfdemos;


import jakarta.enterprise.context.RequestScoped;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

//ProductBean.java->GSTConfigBean.java->CartBean.java=>gstshoppingcart.xhtml
@Named
//@RequestScoped
@SessionScoped
public class CartBean implements Serializable {

    private ProductBean product = new ProductBean();
    private List<ProductBean> cartItems = new ArrayList<>();

    private String state;
    private String coupon;

    private double finalAmount;
    private double subTotal;
    private double gstAmount;
    private double discount;

    private String result;

    //No manual object creation
    @Inject//No need to recreate GST logic every request
    private GSTConfigBean gstConfig;//Inject ApplicationScoped into RequestScoped using @Inject

    // Add product to cart
    public void addToCart() {
        cartItems.add(new ProductBean(
                product.getName(),
                product.getPrice(),
                product.getQuantity()
        ));
        product = new ProductBean(); // reset form
    }

    // Calculate invoice
    public void calculate() {

        subTotal = 0;

        for (ProductBean p : cartItems) {
            subTotal += p.getTotal();
        }

        double gstRate = gstConfig.getGstRate(state);
        gstAmount = subTotal * gstRate;

        discount = 0;

        if ("SAVE10".equalsIgnoreCase(coupon)) {
            discount = subTotal * 0.10;
        } else if ("SAVE20".equalsIgnoreCase(coupon)) {
            discount = subTotal * 0.20;
        }

        finalAmount = subTotal + gstAmount - discount;

        result = "Subtotal: " + subTotal +
                 ", GST: " + gstAmount +
                 ", Discount: " + discount +
                 ", Final: " + finalAmount;
    }

    // getters & setters
    public ProductBean getProduct() { return product; }
    public List<ProductBean> getCartItems() { return cartItems; }

    public String getState() { return state; }
    public void setState(String state) { this.state = state; }

    public String getCoupon() { return coupon; }
    public void setCoupon(String coupon) { this.coupon = coupon; }

    public double getFinalAmount() { return finalAmount; }
    public double getSubTotal() { return subTotal; }
    public double getGstAmount() { return gstAmount; }
    public double getDiscount() { return discount; }

    public String getResult() { return result; }
}