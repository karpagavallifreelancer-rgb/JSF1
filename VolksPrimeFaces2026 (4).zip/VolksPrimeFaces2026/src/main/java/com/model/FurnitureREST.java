package com.model;

/*
 * ✅ 1. WHAT (What is REST API?)

REST API = a way for frontend (PrimeFaces UI) to communicate with backend services using HTTP.

Uses:
GET → fetch data
POST → create
PUT → update
DELETE → remove

👉 In PrimeFaces:

UI (JSF page) calls REST endpoints instead of direct managed bean logic (in modern apps)

✅ 2. WHY (Why use REST API in PrimeFaces?)

Separation of concerns (UI ≠ backend)
Reusable backend (mobile, web, microservices)
Scalable architecture
Works well with AJAX & JSON

👉 Example:

PrimeFaces form → calls REST API → backend returns JSON → UI updates

✅ 3. WHEN (When to use?)

Use REST API with PrimeFaces when:

Building microservices architecture
Multiple clients (mobile + web)
Need decoupled frontend/backend
Using AJAX heavy UI

❌ Avoid when:

Small monolithic JSF app
Simple CRUD with managed beans is enough

✅ 4. WHERE (Where is it used?)

Between PrimeFaces UI (Frontend) and Spring Boot / Java backend
Across:
Web apps
Mobile apps
Cloud services

👉 Flow:

PrimeFaces UI → AJAX → REST API → Database

✅ 5. HOW (How it works?)

🔹 Step-by-step flow:
User interacts with PrimeFaces UI (button/input)
AJAX call is triggered
REST API endpoint is called
Backend processes request
JSON response returned
UI updates dynamically

REST Principles:::


| Rule           | Explanation                    |
| -------------- | ------------------------------ |
| Stateless      | Each request independent       |
| Resource-based | URLs represent data (`/users`) |
| HTTP methods   | Use proper verbs               |
| JSON format    | Standard data exchange         |
| Client-server  | UI & backend separate          |

WHAT (What is JSON Server?)

JSON Server = a fake REST API generator

→ It creates a full REST API instantly from a simple JSON file
→ No backend coding required

✅ 2. WHY (Why use JSON Server?)
🔹 Fast Development

→ No need to build backend
→ Start API in seconds

🔹 Frontend Testing

→ Perfect for testing PrimeFaces AJAX calls
→ Simulates real REST API

🔹 Prototyping

→ Quickly build demo apps
→ Useful for assignments/projects

🔹 Learning REST API

→ Understand:

HTTP methods
JSON data
API structure
🔹 Decoupled Development

→ Frontend team can work without backend ready
 */
/*
 * C:\Users\Administrator>node -v
v14.21.3

C:\Users\Administrator>npm -v
6.14.13

D:\Volkswagen_JSF>cd jso*

D:\Volkswagen_JSF\JSONMOCKRESTAPI>json-server --watch mydb.json

  \{^_^}/ hi!

  Loading mydb.json
  Done

  Resources
  http://localhost:3000/furniture

  Home
  http://localhost:3000

  Type s + enter at any time to create a snapshot of the database
  Watching...

GET /db 200 2.152 ms - 583
GET /__rules 404 15.211 ms - 2
GET /furniture 200 36.096 ms - 502
GET /furniture 304 29.183 ms - -
POST /furniture 201 127.183 ms - 133
GET /furniture 200 29.201 ms - 655
POST /furniture 201 23.526 ms - 133
POST /furniture 201 28.710 ms - 133
GET /furniture 200 18.383 ms - 961
POST /furniture 201 29.000 ms - 146
GET /furniture 200 30.063 ms - -

 */
public class FurnitureREST {
	 private int id;
	    private String productName;
	    private int quantity;
	    private double price;

	    private double total;
	    private double discount;
	    private double finalAmount;
		public FurnitureREST()
		{
			
		}
	    public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getProductName() {
			return productName;
		}
		public void setProductName(String productName) {
			this.productName = productName;
		}
		public int getQuantity() {
			return quantity;
		}
		public void setQuantity(int quantity) {
			this.quantity = quantity;
		}
		public double getPrice() {
			return price;
		}
		public void setPrice(double price) {
			this.price = price;
		}
		public double getTotal() {
			return total;
		}
		public void setTotal(double total) {
			this.total = total;
		}
		public double getDiscount() {
			return discount;
		}
		public void setDiscount(double discount) {
			this.discount = discount;
		}
		public double getFinalAmount() {
			return finalAmount;
		}
		public void setFinalAmount(double finalAmount) {
			this.finalAmount = finalAmount;
		}
}
