package com.model;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

//CRUD BUSINESS LOGIC
public class ElectionService {

    private static final String API_URL = "http://localhost:3000/elections";

    public List<Election> getAllElections() {
        List<Election> electionList = new ArrayList<>();

        try {
            URL url = new URL(API_URL);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(connection.getInputStream()));

            StringBuilder response = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                response.append(line);
            }

            reader.close();

            ObjectMapper mapper = new ObjectMapper();
            electionList = mapper.readValue(response.toString(),
                    new TypeReference<List<Election>>() {});//JSON → List<Election>

        } catch (Exception e) {
            e.printStackTrace();
        }

        return electionList;
    }

    public void addElection(Election election) {
        try {
            URL url = new URL(API_URL);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);

            ObjectMapper mapper = new ObjectMapper();
            String jsonInput = mapper.writeValueAsString(election);

            OutputStream os = connection.getOutputStream();
            os.write(jsonInput.getBytes());
            os.flush();
            os.close();

            connection.getResponseCode();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateElection(Election election) {
        try {
            URL url = new URL(API_URL + "/" + election.getId());
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            connection.setRequestMethod("PUT");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);

            ObjectMapper mapper = new ObjectMapper();
            String jsonInput = mapper.writeValueAsString(election);

            OutputStream os = connection.getOutputStream();
            os.write(jsonInput.getBytes());
            os.flush();
            os.close();

            connection.getResponseCode();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteElection(int id) {
        try {
            URL url = new URL(API_URL + "/" + id);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("DELETE");
            connection.getResponseCode();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
