package com.managedbeans;
import java.io.Serializable;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;

@Named
@ViewScoped
//StationeryBean.java->debouncing_onblur.xhtml

public class StationeryBean implements Serializable {

    private String itemName;
    private int quantity;
    private double price;
    private double discount;
    public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	private double total;

    public void calculate() {

        double subtotal = quantity * price;

        // Condition
        if (quantity > 10) {
            discount = subtotal * 0.10; // 10% discount
        } else {
            discount = 0;
        }

        total = subtotal - discount;
    }
}