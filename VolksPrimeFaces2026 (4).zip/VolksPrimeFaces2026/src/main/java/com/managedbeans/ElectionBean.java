package com.managedbeans;

import java.io.Serializable;
import java.util.List;

import com.model.Election;
import com.model.ElectionService;

import jakarta.annotation.PostConstruct;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;
/*
 * 
D:\Volkswagen_JSF\JSONMOCKRESTAPI>json-server --watch mydb12.json --port 3000

  \{^_^}/ hi!

  Loading mydb12.json
  Done

  Resources
  http://localhost:3000/elections

  Home
  http://localhost:3000

  Type s + enter at any time to create a snapshot of the database
  Watching...

GET /db 200 2.670 ms - 351
GET /__rules 404 3.523 ms - 2
GET /elections 200 22.607 ms - 298
GET /elections 200 22.775 ms - 298
GET /elections 200 29.937 ms - 298
GET /elections 200 24.944 ms - 298
POST /elections 201 143.311 ms - 122
GET /elections 200 4.307 ms - 438
GET /elections 200 23.079 ms - 438
POST /elections 201 26.357 ms - 122
GET /elections 200 7.206 ms - 578
GET /elections 200 27.482 ms - 578
GET /elections 200 13.371 ms - 578
GET /elections 200 27.970 ms - 578
POST /elections 201 17.809 ms - 118
GET /elections 200 5.299 ms - 714
PUT /elections/5 200 13.746 ms - 124
GET /elections 200 7.013 ms - 720
PUT /elections/2 200 30.956 ms - 129
GET /elections 200 9.044 ms - 720
DELETE /elections/3 200 32.368 ms - 2
GET /elections 200 7.780 ms - 580
PUT /elections/1 200 25.230 ms - 131
GET /elections 200 5.241 ms - 580
GET /elections 200 29.589 ms - 580

 */
@Named
@ViewScoped

//Election.java->ElectionService.java->ElectionBean.java->election_crudrestapi.xhtml
public class ElectionBean implements Serializable {

    private List<Election> elections;
    private Election selectedElection = new Election();

    private ElectionService service = new ElectionService();

    @PostConstruct
    public void init() {
        loadData();
    }

    public void loadData() {
        elections = service.getAllElections();
    }
/*
 * 1. Candidate name cannot be empty
2. Candidate age must be greater than 25
3. If votes > 10000, status = Leading
4. If votes <= 10000, status = Trailing

 */
    public void saveElection() {

        if (selectedElection.getCandidateName() == null || selectedElection.getCandidateName().isEmpty()) {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Validation", "Candidate name is required"));
            return;
        }

        if (selectedElection.getAge() < 25) {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Validation", "Candidate age must be above 25"));
            return;
        }

        if (selectedElection.getVotes() > 10000) {
            selectedElection.setStatus("Leading");
        } else {
            selectedElection.setStatus("Trailing");
        }

        if (selectedElection.getId() == 0) {
            service.addElection(selectedElection);
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage("Election added successfully"));
        } else {
            service.updateElection(selectedElection);
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage("Election updated successfully"));
        }

        selectedElection = new Election();
        loadData();
    }

    public void editElection(Election e) {
        selectedElection = new Election();
        selectedElection.setId(e.getId());
        selectedElection.setCandidateName(e.getCandidateName());
        selectedElection.setParty(e.getParty());
        selectedElection.setAge(e.getAge());
        selectedElection.setVotes(e.getVotes());
        selectedElection.setStatus(e.getStatus());
    }
    public void clear() {
        selectedElection = new Election();
    }
    public void deleteElection(Election election) {
        service.deleteElection(election.getId());
        loadData();

        FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage("Election deleted successfully"));
    }

    public List<Election> getElections() {
        return elections;
    }

    public void setElections(List<Election> elections) {
        this.elections = elections;
    }

    public Election getSelectedElection() {
        return selectedElection;
    }

    public void setSelectedElection(Election selectedElection) {
        this.selectedElection = selectedElection;
    }
}
