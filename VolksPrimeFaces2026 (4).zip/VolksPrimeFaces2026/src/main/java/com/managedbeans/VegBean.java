package com.managedbeans;

import java.io.Serializable;

import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;

@Named
@ViewScoped
public class VegBean implements Serializable {

    private String name;
    private double price;
    private int quantity;

    public void checkStatus() {

        FacesContext context = FacesContext.getCurrentInstance();

        if (quantity > 20) {
            context.addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO,
                "Fresh Stock", name + " is available in bulk ✔"));
        }
        else if (quantity > 0) {
            context.addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_WARN,
                "Low Stock", name + " is running low ⚠"));
        }
        else {
            context.addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_ERROR,
                "Out of Stock", name + " not available ✖"));
        }
    }

    // Getters & Setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
}