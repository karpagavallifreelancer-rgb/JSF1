package com.managedbeans;
import java.io.Serializable;
import jakarta.inject.Named;
import jakarta.faces.view.ViewScoped;

/*
 * In PrimeFaces, reducing AJAX calls is mainly about avoiding unnecessary server hits and 
 * updating only what is needed.
 * 
 * 🧠 KEY IDEA (VERY IMPORTANT)

Instead of calling AJAX on every input:

❌ bad:

<p:ajax event="keyup" ... />

✔ good:

Call only on button click
OR use onblur
OR use delay + partialSubmit

🟧 IMPROVED VERSION (EVEN LESS SERVER LOAD)
✔ Use onblur instead of AJAX typing
<p:inputText value="#{footballBean.matches}">
    <p:ajax event="blur" process="@this"/>
</p:inputText>

<p:inputText value="#{footballBean.goals}">
    <p:ajax event="blur" process="@this"/>
</p:inputText>

👉 This reduces calls from:

every keystroke ❌
to only when user leaves field ✔

| Approach                        | AJAX Calls   | Performance |
| ------------------------------- | ------------ | ----------- |
| keyup AJAX                      | 🔴 Many      | Slow        |
| blur event                      | 🟡 Medium    | OK          |
| button click (recommended)      | 🟢 One       | Best        |
| process="@form + update=target" | 🟢 Optimized | Best        |

⚽ FINAL OPTIMIZED RULES

✔ Use commandButton for calculations
✔ Use process="@form" only when needed
✔ Use update="specificPanel" not @all
✔ Avoid keyup / change AJAX for numeric fields
✔ Prefer manual trigger over automatic AJAX

========================================
⚡ PrimeFaces Resource Optimization (Concise)

🟦 Categories

CSS → themes, custom styles
JS → PrimeFaces core + component scripts
Images → icons, theme graphics
External libs → jQuery, FontAwesome, plugins

⚙️ Optimization Rules

Use single theme only
Avoid duplicate CSS/JS loading
Use h:outputStylesheet / h:outputScript
Enable minification (CSS + JS)
Combine CSS/JS into bundles
Use lazy loading components (dataTable lazy, dialog dynamic)
Load JS/CSS only when required
Enable browser caching
Reduce initial heavy components
Avoid unnecessary AJAX calls

⚠️ Limitations

Auto resource loading by PrimeFaces (less control)
Heavy components increase initial load
Theme switching reloads full CSS
AJAX still causes server round-trips
Browser caching depends on server config

🚀 One-Line Summary

PrimeFaces resource optimization focuses on reducing CSS/JS load, avoiding duplication, 
enabling minification, using lazy loading, and minimizing AJAX and initial rendering 
overhead for better performance.

Key Optimization Idea

👉 Instead of:

“AJAX on every field change (heavy load)”

✔ Use:

“One controlled calculation action (light + fast)”
 */
@Named("footballBean")
@ViewScoped


//FootBallBean.java->ajaxcalloptimization.xhtml
public class FootBallBean implements Serializable{

    private String player;
    private int matches;
    public String getPlayer() {
		return player;
	}

	public void setPlayer(String player) {
		this.player = player;
	}

	public int getMatches() {
		return matches;
	}

	public void setMatches(int matches) {
		this.matches = matches;
	}

	public int getGoals() {
		return goals;
	}

	public void setGoals(int goals) {
		this.goals = goals;
	}

	public double getRatio() {
		return ratio;
	}

	public void setRatio(double ratio) {
		this.ratio = ratio;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	private int goals;

    private double ratio;
    private String rating;

    public void calculate() {

        ratio = (matches > 0) ? (double) goals / matches : 0;

        if (ratio >= 0.7) {
            rating = "⭐ Superstar";
        } else if (ratio >= 0.4) {
            rating = "👍 Good";
        } else {
            rating = "⚽ Average";
        }
    }


}