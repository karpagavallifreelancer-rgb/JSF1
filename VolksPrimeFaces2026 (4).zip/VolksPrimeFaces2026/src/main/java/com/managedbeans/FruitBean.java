package com.managedbeans;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;

@Named
@ViewScoped
/*
 * JSTL in PrimeFaces (JSF) – Summary::
 * 
📂 Categories Used

Core (c) → if, forEach, choose
Functions (fn) → string operations
Format (fmt) → date/number formatting

⚙️ Rules

Use only for view-level logic
Executes before JSF lifecycle builds UI
Should NOT contain business logic
Prefer JSF rendered instead of JSTL
Avoid inside AJAX-updated components

⚠️ Limitations

❌ Not JSF lifecycle aware
❌ Breaks AJAX dynamic updates
❌ UI components may not refresh properly
❌ Not suitable for dynamic PrimeFaces UI
❌ Executes only once at page build time

🔥 Best Practice

✔ Use JSTL for simple static conditions
✔ Use PrimeFaces/JSF rendered for dynamic UI
❌ Avoid JSTL for interactive or AJAX-based UI

📊 One-line Conclusion

👉 JSTL = simple view logic
👉 PrimeFaces = full dynamic UI framework
👉 JSF rendered = preferred replacement for JSTL in most cases

| Feature         | JSTL             | PrimeFaces      |
| --------------- | ---------------- | --------------- |
| Role            | View logic       | UI framework    |
| Lifecycle       | Before JSF build | JSF runtime     |
| AJAX support    | ❌ No             | ✅ Yes           |
| Dynamic UI      | ❌ Limited        | ✅ Strong        |
| Recommended use | Minimal          | Primary UI tool |

===================================================================================
⚠️ Thymeleaf does NOT run inside JSF (.xhtml) and does NOT use ManagedBean.
JSF uses Facelets (.xhtml) + ManagedBean
Thymeleaf uses HTML templates + controller/servlet (always needed)

👉 ✔ JSF + ManagedBean is full working MVC
👉 ✔ Thymeleaf needs backend (Servlet/Spring) to be dynamic

| Feature     | PrimeFaces       | Thymeleaf (No Boot) |
| ----------- | ---------------- | ------------------- |
| Type        | JSF UI framework | Template engine     |
| Backend     | ManagedBean      | Servlet             |
| Calculation | Bean method      | Servlet logic       |
| UI Update   | AJAX (`update`)  | Full page reload    |
| Server      | JSF runtime      | Servlet container   |

 */



//FruitBean.java->primefaces_jstldemo.xhtml
public class FruitBean implements Serializable {

    private List<Fruit> fruits;

    public FruitBean() {
        fruits = new ArrayList<>();

        fruits.add(new Fruit("Apple", 120, 10));
        fruits.add(new Fruit("Banana", 40, 0));
        fruits.add(new Fruit("Mango", 150, 5));
        fruits.add(new Fruit("Orange", 80, 20));
    }

    public List<Fruit> getFruits() {
        return fruits;
    }

    public static class Fruit {
        private String name;
        private int price;
        private int stock;

        public Fruit(String name, int price, int stock) {
            this.name = name;
            this.price = price;
            this.stock = stock;
        }

        public String getName() { return name; }
        public int getPrice() { return price; }
        public int getStock() { return stock; }
    }
}